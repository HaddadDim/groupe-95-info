#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void triBulles(int *numero, char prenom[][30], char nom[][30], char appel[][30]) {
    long debut = clock();
    int stockNum;
    char stockPrenom[30], stockNom[30], stockAppel[30];
    for (int i = 0; i < 1000; i++) {
        for (int j = 0; j < 999 - i; j++) {
            if (numero[j] > numero[j + 1]) {
                stockNum = numero[j];
                numero[j] = numero[j + 1];
                numero[j + 1] = stockNum;
                strcpy(stockPrenom, prenom[j]);
                strcpy(prenom[j], prenom[j + 1]);
                strcpy(prenom[j + 1], stockPrenom);

                strcpy(stockNom, nom[j]);
                strcpy(nom[j], nom[j + 1]);
                strcpy(nom[j + 1], stockNom);

                strcpy(stockAppel, appel[j]);
                strcpy(appel[j], appel[j + 1]);
                strcpy(appel[j + 1], stockAppel);
            }
        }
    }
    printf("temps : %ld ms\n", clock() - debut);
    for(int i=0; i<1000;i++){
        printf("%d/ %s/ %s/ %s\n", numero[i], prenom[i], nom[i], appel[i]);
    }
}

void triInsertion(int *numero, char prenom[][30], char nom[][30], char appel[][30]) {
    long debut = clock();
    int stockNum;
    char stockPrenom[30], stockNom[30], stockAppel[30];
    int j;
    for(int i=0;i<1000;i++){
        j=i;
        while(j>0 && numero[j-1]>numero[j]){
            stockNum=numero[j];
            numero[j]=numero[j-1];
            numero[j-1]=stockNum;
            strcpy(stockPrenom, prenom[j]);
            strcpy(prenom[j], prenom[j - 1]);
            strcpy(prenom[j - 1], stockPrenom);

            strcpy(stockNom, nom[j]);
            strcpy(nom[j], nom[j - 1]);
            strcpy(nom[j - 1], stockNom);

            strcpy(stockAppel, appel[j]);
            strcpy(appel[j], appel[j - 1]);
            strcpy(appel[j - 1], stockAppel);

            j--;
        }
    }
    printf("temps : %ld ms\n", clock() - debut);
    for(int i=0; i<1000;i++){
        //printf("%d/ %s/ %s/ %s\n", numero[i], prenom[i], nom[i], appel[i]);
    }
}
void histogramme(int numero[], char prenom[][30], char nom[][30], char appel[][30]) {
    long debut=clock();
    int compteur=1;
    for(int i=0;i<1000;i++){
        if(numero[i]==numero[i+1]){
            compteur=compteur+1;
        }
        else{
            printf("%s %s :",prenom[i],nom[i]);
            for(int j=0;j<compteur;j++){
                printf(".");
            }
            printf("\n");
            compteur=1;
        }
    }
    printf("temps : %ld ms\n", clock() - debut);
    int compteurEntrant=0, compteurSortant=0;
    for(int i=0;i<1000;i++){
        if(strcmp(prenom[i],"Oscar")==0 && strcmp(appel[i],"Entrant")==0){
            compteurEntrant++;
        }
        else if (strcmp(prenom[i],"Oscar")==0 && strcmp(appel[i],"Sortant")==0){
            compteurSortant++;
        }
    }
    printf("Nombre d'appels entrants d'Oscar RIOTTO : %d\nNombre d'appels sortants d'Oscar RIOTTO: %d ",compteurEntrant,compteurSortant);
    }

void histoNbAleatoire(){
    int nbAleatoire[1000];
    for(int i=0;i<1000;i++){
        nbAleatoire[i]=rand()%25;
        //printf("%d\n",nbAleatoire[i]);
    }


    int j, stock;
    for(int i=1;i<1000;i++) {
        j = i;
        while (j > 0 && nbAleatoire[j - 1] > nbAleatoire[j]) {
            stock = nbAleatoire[j];
            nbAleatoire[j] = nbAleatoire[j - 1];
            nbAleatoire[j - 1] = stock;
            j--;
        }
    }
    printf("\nTableau trié :\n");
    for(int i=0;i<1000;i++){
        //printf("%d\n",nbAleatoire[i]);
    }
    int freq[25] = {0};
    int debut=clock();
    for(int i=0;i<1000;i++){
        freq[nbAleatoire[i]]++;
    }

    printf("\nHistogramme :\n");
    for(int i=0;i<25;i++){
        printf("%2d : ", i);
        for(int j=0;j<freq[i];j++){
            printf("|");
        }
        printf("\n");
    }
    printf("%d ms\n",clock()-debut);
    int compteur=1;
    debut=clock();
    for(int i=0;i<1000;i++){
        if(nbAleatoire[i]==nbAleatoire[i+1]){
            compteur=compteur+1;
        }
        else{
            printf("%d:",nbAleatoire[i]);
            for(int j=0;j<compteur;j++){
                printf(".");
            }
            printf("\n");
            compteur=1;
        }
    }
    printf("%d ms",clock()-debut);
}

int main() {
    FILE* fichierSource = fopen("releve.txt", "r");
    if (!fichierSource) {
        printf("Erreur lors de l'ouverture du fichier\n");
        return 1;
    }

    int numero[1000];
    char nom[1000][30];
    char prenom[1000][30];
    char appel[1000][30];
    for (int i = 0; i < 1000; i++) {
        fgetc(fichierSource);
        fgetc(fichierSource);
        fgetc(fichierSource);
        fgetc(fichierSource);
        fgetc(fichierSource);

        fscanf(fichierSource, "%d", &numero[i]);
        fscanf(fichierSource, "%s", prenom[i]);
        fscanf(fichierSource, "%s", nom[i]);
        fscanf(fichierSource, "%s", appel[i]);
        //printf("%d/ %s/ %s/ %s\n", numero[i], prenom[i], nom[i], appel[i]);
    }
    srand(time(NULL));
    triBulles(numero,prenom,nom,appel);
    triInsertion(numero,prenom,nom,appel);
    histogramme(numero,prenom,nom,appel);
    histoNbAleatoire();
    return 0;
}
