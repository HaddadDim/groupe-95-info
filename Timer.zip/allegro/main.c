#include <allegro.h>

#define NOMBRE_IMAGES 6
#define VITESSE_ANIMATION 5

int main() {
    // Initialisation Allegro
    allegro_init();
    install_keyboard();
    set_color_depth(32);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0);

    // Chargement des images du chat
    BITMAP* images_chat[NOMBRE_IMAGES];
    char filename[20];
    for (int i = 0; i < NOMBRE_IMAGES; ++i) {
        sprintf(filename, "cat%d.bmp", i);
        images_chat[i] = load_bitmap(filename, NULL);
        if (!images_chat[i]) {
            allegro_message("Impossible de charger l'image %s", filename);
            return 1;
        }
    }

    // Chargement de l'image du décor
    BITMAP* decor = load_bitmap("decor.bmp", NULL);
    if (!decor) {
        allegro_message("Impossible de charger l'image du décor");
        return 1;
    }

    // Variables de contrôle de l'animation
    int img_courante = 0;
    int cpt_img = 0;

    // Position initiale du chat
    int x_chat = SCREEN_W / 2;
    int y_chat = 0;

    // Boucle principale du jeu
    while (!key[KEY_ESC]) {
        // Affichage du décor
        blit(decor, screen, 0, 0, 0, 0, SCREEN_W, SCREEN_H);

        // Affichage du chat
        draw_sprite(screen, images_chat[img_courante], x_chat, y_chat);

        // Gestion de l'animation du chat en chute libre
        cpt_img++;
        if (cpt_img >= VITESSE_ANIMATION) {
            cpt_img = 0;
            img_courante = (img_courante + 1) % NOMBRE_IMAGES;
            y_chat += 5; // Chute libre
        }

        // Si le chat touche le sol
        if (y_chat >= SCREEN_H / 2) {
            // Le chat se redresse
            img_courante = 0;

            // Le chat s'enfuit vers le bord de l'écran le plus proche
            if (x_chat < SCREEN_W / 2) {
                x_chat -= 5; // Partir vers la gauche
            } else {
                x_chat += 5; // Partir vers la droite
            }

            // Si le chat sort complètement de l'écran, il est réinitialisé en haut
            if (x_chat < -images_chat[0]->w || x_chat > SCREEN_W) {
                x_chat = rand() % SCREEN_W; // Position aléatoire en X
                y_chat = 0; // Retour en haut
            }
        }

        // Rafraîchissement de l'écran
        rest(20);
    }

    // Libération de la mémoire
    for (int i = 0; i < NOMBRE_IMAGES; ++i) {
        destroy_bitmap(images_chat[i]);
    }
    destroy_bitmap(decor);

    return 0;
}
END_OF_MAIN();
